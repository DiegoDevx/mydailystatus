import React from 'react'

const Entrar = () => {
  return <h1>Entrar</h1>
}
export default Entrar
