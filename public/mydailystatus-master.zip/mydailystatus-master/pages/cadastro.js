import React from 'react'

const Cadastro = () => {
  return <h1>Cadastro</h1>
}
export default Cadastro
