require('dotenv').config()

module.exports = {}
